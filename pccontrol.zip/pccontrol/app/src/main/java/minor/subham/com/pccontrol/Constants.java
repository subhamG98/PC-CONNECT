package minor.subham.com.pccontrol;

/**
 * Created by Sourabh Soni on 07-03-2015.
 */
public class Constants {
    public static final String SERVER_IP = start.ip.getText().toString();
    public static final int SERVER_PORT = Integer.parseInt(start.port.getText().toString());
    public static final String PLAY="play";
    public static final String NEXT="next";
    public static final String PREVIOUS="previous";
    public static final String RCLICK="rclick";
    public static final String LCLICK="lclick";
    public static final String MUTE="mute";
    public static final String MOUSE_LEFT_CLICK="left_click";
}
