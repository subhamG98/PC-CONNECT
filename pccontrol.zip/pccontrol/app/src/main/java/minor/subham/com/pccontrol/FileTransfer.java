package minor.subham.com.pccontrol;

        import android.app.Dialog;
        import android.app.ProgressDialog;
        import android.content.Context;
        import android.content.DialogInterface;
        import android.content.Intent;
        import android.database.Cursor;
        import android.graphics.BitmapFactory;
        import android.net.Uri;
        import android.net.wifi.WifiConfiguration;
        import android.net.wifi.WifiManager;
        import android.os.AsyncTask;
        import android.os.Environment;
        import android.provider.MediaStore;
        import android.support.v7.app.ActionBarActivity;
        import android.os.Bundle;
        import android.support.v7.app.AlertDialog;
        import android.text.format.Formatter;
        import android.util.Log;
        import android.view.Menu;
        import android.view.MenuItem;
        import android.view.View;
        import android.webkit.MimeTypeMap;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.ImageView;
        import android.widget.TextView;
        import android.widget.Toast;

        import org.apache.http.HttpEntity;
        import org.apache.http.HttpResponse;
        import org.apache.http.client.ClientProtocolException;
        import org.apache.http.client.HttpClient;
        import org.apache.http.client.methods.HttpPost;
        import org.apache.http.impl.client.DefaultHttpClient;
        import org.json.JSONArray;
        import org.json.JSONObject;

        import java.io.BufferedInputStream;
        import java.io.BufferedOutputStream;
        import java.io.BufferedReader;
        import java.io.DataInputStream;
        import java.io.DataOutputStream;
        import java.io.File;
        import java.io.FileInputStream;
        import java.io.FileOutputStream;
        import java.io.IOException;
        import java.io.InputStream;
        import java.io.InputStreamReader;
        import java.io.OutputStream;
        import java.io.PrintWriter;
        import java.io.UnsupportedEncodingException;
        import java.lang.reflect.Method;
        import java.net.Socket;
        import java.net.UnknownHostException;
        import java.util.List;


public class FileTransfer extends ActionBarActivity {

    //Button send;

    ImageView imgPreview;

    Socket socket;
    String filename;
    private static final int SELECT_PICTURE = 1;
    private Dialog loadingDialog;
    private String selectedImagePath;


    public static String getMimeType(String url) {
        String type = null;
        String extension = MimeTypeMap.getFileExtensionFromUrl(url);
        if (extension != null) {
            type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
        }
        return type;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_transfer);
      //  send=(Button)findViewById(R.id.send);
        imgPreview=(ImageView)findViewById(R.id.imgPreview);

        imgPreview.setOnClickListener(

                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //Choose Image
                        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(FileTransfer.this);
                        alertDialogBuilder.setMessage("Select File to Transfer ").setPositiveButton("Browse", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent intent = new Intent();
                                intent.setType("*/*");
                                intent.setAction(Intent.ACTION_GET_CONTENT);
                                startActivityForResult(Intent.createChooser(intent,
                                        "Select File"), SELECT_PICTURE);
                            }

                        }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        });
                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();


                    }
                }
        );





    }


    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            if (requestCode == SELECT_PICTURE) {
                Uri selectedImageUri = data.getData();
                selectedImagePath = getPath(selectedImageUri);
                String type=getMimeType(selectedImagePath);
                Toast.makeText(getApplicationContext(),""+selectedImagePath+"Type="+type,Toast.LENGTH_LONG).show();
              //  imgPreview.setImageBitmap(BitmapFactory.decodeFile(selectedImagePath));
                filename=selectedImagePath.substring(selectedImagePath.lastIndexOf("/") + 1);
                Log.i("very imp filename",""+filename);
                connect_python(Constants.SERVER_IP);

            }
        }



    }

    public String getPath(Uri uri) {
        // just some safety built in
        if( uri == null ) {
            // TODO perform some logging or show user feedback
            return null;
        }
        // try to retrieve the image from the media store first
        // this will only work for images selected from gallery
        String[] projection = { MediaStore.Images.Media.DATA };
        Cursor cursor = managedQuery(uri, projection, null, null, null);
        if( cursor != null ){
            int column_index = cursor
                    .getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            return cursor.getString(column_index);
        }
        // this is our fallback here
        return uri.getPath();
    }

    private void connect_python(String ipAddress) {

        MyClientTask myClientTask = new MyClientTask(
                ipAddress,
                Constants.SERVER_PORT);
        myClientTask.execute();
    }


    public class MyClientTask extends AsyncTask<Void, Void, Void> {

        String dstAddress;
        int dstPort;
        String message;
        String response = "";

        MyClientTask(String addr, int port){
            dstAddress = addr;
            dstPort = port;

        }

        @Override
        protected Void doInBackground(Void... arg0) {

            socket = null;

            try {
                socket = new Socket(dstAddress, dstPort);



                OutputStream outstream = socket .getOutputStream();
                PrintWriter out = new PrintWriter(outstream);
                String toSend = filename;
                out.print(toSend);
                out.flush();

                OutputStream os = socket.getOutputStream();

                File myFile = new File(selectedImagePath);
                byte [] mybytearray  = new byte [(int)myFile.length()];
                FileInputStream fis = new FileInputStream(myFile);
                BufferedInputStream bis = new BufferedInputStream(fis);
                bis.read(mybytearray, 0, mybytearray.length);

                os.write(mybytearray, 0, mybytearray.length);
                os.flush();



                socket.close();

            } catch (UnknownHostException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                response = "UnknownHostException: " + e.toString();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                response = "IOException: " + e.toString();
            }finally{

                if(socket != null){
                    try {
                        socket.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }

            return null;
        }
        @Override
        protected void onPreExecute() {
            loadingDialog = ProgressDialog.show(FileTransfer.this, "Please wait", "Sending...");

            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Void result) {
            loadingDialog.dismiss();
            if(response.contains("Exception")){
                Toast.makeText(getApplicationContext(),"Error Occured: "+response,Toast.LENGTH_LONG).show();
            }else{
                Toast.makeText(getApplicationContext(),"Sent "+filename,Toast.LENGTH_LONG).show();
            }
            super.onPostExecute(result);
        }













    }




}
