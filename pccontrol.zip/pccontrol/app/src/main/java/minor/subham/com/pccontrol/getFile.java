package minor.subham.com.pccontrol;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Environment;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import java.net.*;
import java.io.*;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;




public class getFile extends ActionBarActivity {

    ImageView getFile;
    public final static int SOCKET_PORT = Constants.SERVER_PORT;      // you may change this
    public final static String SERVER = Constants.SERVER_IP;  // localhost

    public final static int FILE_SIZE = 6022386; // file size temporary hard coded
    // should bigger than the file to be downloaded



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_file);

        getFile = (ImageView) findViewById(R.id.getFile);





        getFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(getApplicationContext(),"Connecting!",Toast.LENGTH_SHORT).show();
                Thread thread = new Thread() {
                    @Override
                    public void run() {


                        int bytesRead;
                        int current = 0;
                        Log.i("Gettabcde1", "=" );
                        ServerSocket serverSocket = null;
                        try {
                            serverSocket = new ServerSocket(Constants.SERVER_PORT);
                            serverSocket.setReuseAddress(true);
                            Log.i("Gettabcde2", "=" );

                        while(true) {
                            Socket clientSocket = null;
                            clientSocket = serverSocket.accept();

                            InputStream in = clientSocket.getInputStream();

                            DataInputStream clientData = new DataInputStream(in);

                            String fileName = clientData.readUTF();
                            OutputStream output = new FileOutputStream(fileName);
                            long size = clientData.readLong();
                            byte[] buffer = new byte[1024];
                            while (size > 0 && (bytesRead = clientData.read(buffer, 0, (int)Math.min(buffer.length, size))) != -1)
                            {
                                output.write(buffer, 0, bytesRead);
                                size -= bytesRead;
                            }
                            Log.i("Gettabcde3", "=" );
                            // Closing the FileOutputStream handle
                            //in.close();
                            //clientData.close();
                            output.close();
                        }

                        } catch (IOException e) {
                            Log.i("Getting prob","="+e);
                            e.printStackTrace();
                        }


                    }
                };

                thread.start();
                Log.i("Gettabcde", "=" );

            }
        });

    }








}



